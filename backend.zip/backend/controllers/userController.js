const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
require('dotenv').config();

// User Registration
exports.register = async (req, res) => {
  const { name, email, password, address, phoneNumber } = req.body;

  try {
    console.log(req.body);

    let user = await User.findOne({ email });
    if (user) {
      return res.status(400).json({ msg: 'User already exists' });
    }

    user = new User({ name, email, password, address, phoneNumber });
    await user.save();

    const payload = { user: { id: user.id } };
    jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '1h' }, (err, token) => {
      if (err) throw err;
      res.json({ 
        msg: 'User created successfully', 
        token,
        name: user.name,
        address: user.address,
        phoneNumber: user.phoneNumber
      });
    });
  } catch (err) {
    console.error(err.message); // Log the error message
    res.status(500).send('Server error');
  }
};


// User login

exports.login = async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ msg: 'Invalid Credentials' });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ msg: 'Invalid Credentials' });
    }

    const payload = { user: { id: user.id } };
    jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '1hr' }, (err, token) => {
      if (err) throw err;
      res.json({ 
        msg: 'Login successful', 
        token,
        name: user.name ,
        lastLogin: user.lastLogin
      });
      
    });
     user.lastLogin = new Date();  // Update last login time
     await user.save();
  } catch (err) {
    res.status(500).send('Server error');
  }
};

// User profile update
exports.updateProfile = async (req, res) => {
  const { name, address, phoneNumber } = req.body;
  const userId = req.user.id; // the user ID is set in the middleware
  console.log("userId",userId)

  try {
    let user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ msg: 'User not found' });
    }

    // Update user fields
    if (name) user.name = name;
    if (address) user.address = address;
    if (phoneNumber) user.phoneNumber = phoneNumber;

    await user.save();

    res.json({ msg: 'User profile updated successfully', user });
  } catch (err) {
    res.status(500).send('Server error');
  }
};

// getUserById 
exports.getUserById = async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select('-password'); // Exclude the password field
    if (!user) {
      return res.status(404).json({ msg: 'User not found' });
    }
    res.json(user);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};

// getAllUsers
exports.getAllUsers = async (req, res) => {
  try {
    const users = await User.find().select('-password'); // Exclude the password field
    res.json(users);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};

//deleteUser
exports.deleteUser = async (req, res) => {
  try {
    const user = await User.findByIdAndDelete(req.params.id);
    if (!user) {
      return res.status(404).json({ msg: 'User not found' });
    }

    res.json({ msg: 'User deleted successfully' });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};


// active / inactive user
exports.toggleUserStatus = async (req, res) => {
  const { action } = req.body; // Expecting 'activate' or 'deactivate'
  const userId = req.params.id;

  if (action !== 'activate' && action !== 'deactivate') {
    return res.status(400).json({ msg: 'Invalid action' });
  }

  try {
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ msg: 'User not found' });
    }

    // user.isActive = action === 'activate'; // Set isActive based on action
    // await user.save();

    user.isActive = !user.isActive
    await user.save()

    res.json({ 
      msg: `User ${action}d successfully`, 
      user 
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};
