const express = require('express');
const connectDB = require('./config/db');
require('dotenv').config();
const { swaggerRoute } = require('./swagger');

const app = express();

// Connect to the database
connectDB();

const cors = require('cors');

// Init Middleware
app.use(express.json());
app.use(cors()); // Allow cross-origin requests

// Define Routes
app.use('/api/auth', require('./routes/auth'));

// Setup Swagger UI
swaggerRoute(app);

// Define a simple route
app.get('/', (req, res) => res.send('API Running'));

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => console.log(`Server started on port ${PORT}`));
