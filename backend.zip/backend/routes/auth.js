const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const authMiddleware = require('../middleware/authMiddleware');

// User registration and login routes
router.post('/register', userController.register);
router.post('/login', userController.login);

// Profile management routes
router.patch('/updateProfile', authMiddleware, userController.updateProfile);
router.get('/user/:id', authMiddleware, userController.getUserById); // Get user by ID
router.get('/getAllUsers', authMiddleware, userController.getAllUsers); // Get all users
router.delete('/deleteUser/:id', authMiddleware, userController.deleteUser); // Delete user
router.put('/users/status/:id', userController.toggleUserStatus); // Toggle user status

module.exports = router;
