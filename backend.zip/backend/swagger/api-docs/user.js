const register = {
    "post": {
        "tags": ["User Auth API"],
        "summary": "User registration",
        "description": "Registers a new user with the provided details.",
        "operationId": "register",
        "consumes": ["application/json"],
        "produces": ["application/json"],
        "parameters": [
            {
                "in": "body",
                "name": "body",
                "description": "User registration information",
                "required": true,
                "schema": {
                    "type": "object",
                    "properties": {
                        "name": {
                            "type": "string",
                            "example": "John Doe"
                        },
                        "email": {
                            "type": "string",
                            "example": "john@example.com"
                        },
                        "password": {
                            "type": "string",
                            "example": "password123"
                        },
                        "address": {
                            "type": "string",
                            "example": "123 Main St"
                        },
                        "phoneNumber": {
                            "type": "string",
                            "example": "123-456-7890"
                        }
                    },
                    "required": ["name", "email", "password"]
                }
            }
        ],
        "responses": {
            "200": {
                "description": "User registered successfully",
                "schema": {
                    "type": "object",
                    "properties": {
                        "msg": {
                            "type": "string",
                            "example": "User created successfully"
                        },
                        "token": {
                            "type": "string",
                            "example": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                        },
                        "name": {
                            "type": "string",
                            "example": "John Doe"
                        },
                        "address": {
                            "type": "string",
                            "example": "123 Main St"
                        },
                        "phoneNumber": {
                            "type": "string",
                            "example": "123-456-7890"
                        }
                    }
                }
            },
            "400": {
                "description": "User already exists",
                "schema": {
                    "type": "object",
                    "properties": {
                        "msg": {
                            "type": "string",
                            "example": "User already exists"
                        }
                    }
                }
            },
            "500": {
                "description": "Server error",
                "schema": {
                    "type": "object",
                    "properties": {
                        "msg": {
                            "type": "string",
                            "example": "Server error"
                        }
                    }
                }
            }
        }
    }
};

const login = {
    "post": {
        "tags": ["User Auth API"],
        "summary": "User login",
        "description": "Allows a user to log in with their email and password.",
        "operationId": "login",
        "consumes": ["application/json"],
        "produces": ["application/json"],
        "parameters": [
            {
                "in": "body",
                "name": "body",
                "description": "Login credentials",
                "required": true,
                "schema": {
                    "type": "object",
                    "properties": {
                        "email": {
                            "type": "string",
                            "example": "user@example.com"
                        },
                        "password": {
                            "type": "string",
                            "example": "password123"
                        }
                    },
                    "required": ["email", "password"]
                }
            }
        ],
        "responses": {
            "200": {
                "description": "Login successful",
                "schema": {
                    "type": "object",
                    "properties": {
                        "token": {
                            "type": "string",
                            "example": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                        },
                        "msg": {
                            "type": "string",
                            "example": "Login successful"
                        },
                        "name": {
                            "type": "string",
                            "example": "John Doe"
                        },
                        "lastLogin": {
                            "type": "string",
                            "example": "2024-08-01T12:00:00Z"
                        }
                    }
                }
            },
            "400": {
                "description": "Invalid credentials",
                "schema": {
                    "type": "object",
                    "properties": {
                        "msg": {
                            "type": "string",
                            "example": "Invalid credentials"
                        }
                    }
                }
            },
            "500": {
                "description": "Server error",
                "schema": {
                    "type": "object",
                    "properties": {
                        "msg": {
                            "type": "string",
                            "example": "Server error"
                        }
                    }
                }
            }
        }
    }
};

const updateProfile = {
    "patch": {
        "tags": ["User Auth API"],
        "summary": "Update user profile",
        "description": "Updates the profile of the logged-in user.",
        "operationId": "updateProfile",
        "consumes": ["application/json"],
        "produces": ["application/json"],
        "parameters": [
            {
                "in": "header",
                "name": "authorization",
                "description": "Bearer token for authorization",
                "required": true,
                "schema": {
                  "type": "string",
                  "example": "Bearer your-token"
                }
              },
            {
                "in": "body",
                "name": "body",
                "description": "Updated profile information",
                "required": true,
                "schema": {
                    "type": "object",
                    "properties": {
                        "name": {
                            "type": "string",
                            "example": "John Doe"
                        },
                        "address": {
                            "type": "string",
                            "example": "123 Main St"
                        },
                        "phoneNumber": {
                            "type": "string",
                            "example": "123-456-7890"
                        }
                    }
                }
            }
        ],
        "responses": {
            "200": {
                "description": "User profile updated successfully",
                "schema": {
                    "type": "object",
                    "properties": {
                        "msg": {
                            "type": "string",
                            "example": "User profile updated successfully"
                        }
                    }
                }
            },
            "404": {
                "description": "User not found",
                "schema": {
                    "type": "object",
                    "properties": {
                        "msg": {
                            "type": "string",
                            "example": "User not found"
                        }
                    }
                }
            },
            "500": {
                "description": "Server error",
                "schema": {
                    "type": "object",
                    "properties": {
                        "msg": {
                            "type": "string",
                            "example": "Server error"
                        }
                    }
                }
            }
        },
        "security": [
            {
                "Bearer": []
            }
        ]
    }
};

const getUserById = {
    "get": {
        "tags": ["User Auth API"],
        "summary": "Get user by ID",
        "description": "Fetches a user by their ID.",
        "operationId": "getUserById",
        "produces": ["application/json"],
        "parameters": [
            {
                "in": "header",
                "name": "authorization",
                "description": "Bearer token for authorization",
                "required": true,
                "schema": {
                  "type": "string",
                  "example": "Bearer your-token"
                }
              },
            {
                "name": "id",
                "in": "path",
                "description": "ID of the user to retrieve",
                "required": true,
                "type": "string",
                "example": "60d0fe4f5311236168a109ca"
            }
        ],
        "responses": {
            "200": {
                "description": "User fetched successfully",
                "schema": {
                    "type": "object",
                    "properties": {
                        "id": { "type": "string", "example": "60d0fe4f5311236168a109ca" },
                        "name": { "type": "string", "example": "John Doe" },
                        "email": { "type": "string", "example": "john@example.com" },
                        "address": { "type": "string", "example": "123 Main St" },
                        "phoneNumber": { "type": "string", "example": "123-456-7890" }
                    }
                }
            },
            "404": {
                "description": "User not found",
                "schema": {
                    "type": "object",
                    "properties": {
                        "msg": {
                            "type": "string",
                            "example": "User not found"
                        }
                    }
                }
            },
            "500": {
                "description": "Server error",
                "schema": {
                    "type": "object",
                    "properties": {
                        "msg": {
                            "type": "string",
                            "example": "Server error"
                        }
                    }
                }
            }
        },
        "security": [
            {
                "Bearer": []
            }
        ]
    }
};

const getAllUsers = {
    "get": {
        "tags": ["User Auth API"],
        "summary": "Get all users",
        "description": "Fetches all users.",
        "operationId": "getAllUsers",
        "produces": ["application/json"],
        "parameters": [
            {
                "in": "header",
                "name": "authorization",
                "description": "Bearer token for authorization",
                "required": true,
                "schema": {
                  "type": "string",
                  "example": "Bearer your-token"
                }
              },
        ],
        "responses": {
            "200": {
                "description": "Users fetched successfully",
                "schema": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "id": { "type": "string", "example": "60d0fe4f5311236168a109ca" },
                            "name": { "type": "string", "example": "John Doe" },
                            "email": { "type": "string", "example": "john@example.com" },
                            "address": { "type": "string", "example": "123 Main St" },
                            "phoneNumber": { "type": "string", "example": "123-456-7890" }
                        }
                    }
                }
            },
            "500": {
                "description": "Server error",
                "schema": {
                    "type": "object",
                    "properties": {
                        "msg": {
                            "type": "string",
                            "example": "Server error"
                        }
                    }
                }
            }
        },
        "security": [
            {
                "Bearer": []
            }
        ]
    }
};

const deleteUser = {
    "delete": {
        "tags": ["User Auth API"],
        "summary": "Delete user",
        "description": "Deletes a user by their ID.",
        "operationId": "deleteUser",
        "parameters": [
            {
                "in": "header",
                "name": "authorization",
                "description": "Bearer token for authorization",
                "required": true,
                "schema": {
                  "type": "string",
                  "example": "Bearer your-token"
                }
              },
            {
                "name": "id",
                "in": "path",
                "description": "ID of the user to delete",
                "required": true,
                "type": "string",
                "example": "60d0fe4f5311236168a109ca"
            }
        ],
        "responses": {
            "200": {
                "description": "User deleted successfully",
                "schema": {
                    "type": "object",
                    "properties": {
                        "msg": {
                            "type": "string",
                            "example": "User deleted successfully"
                        }
                    }
                }
            },
            "404": {
                "description": "User not found",
                "schema": {
                    "type": "object",
                    "properties": {
                        "msg": {
                            "type": "string",
                            "example": "User not found"
                        }
                    }
                }
            },
            "500": {
                "description": "Server error",
                "schema": {
                    "type": "object",
                    "properties": {
                        "msg": {
                            "type": "string",
                            "example": "Server error"
                        }
                    }
                }
            }
        },
        "security": [
            {
                "Bearer": []
            }
        ]
    }
};

const toggleUserStatus = {
    "put": {
        "tags": ["User Auth API"],
        "summary": "Toggle user status",
        "description": "Activates or deactivates a user based on the provided action.",
        "operationId": "toggleUserStatus",
        "consumes": ["application/json"],
        "produces": ["application/json"],
        "parameters": [
            {
                "in": "header",
                "name": "authorization",
                "description": "Bearer token for authorization",
                "required": true,
                "schema": {
                  "type": "string",
                  "example": "Bearer your-token"
                }
              },
            {
                "name": "id",
                "in": "path",
                "description": "ID of the user to toggle status",
                "required": true,
                "schema": {
                    "type": "string",
                    "example": "60d0fe4f5311236168a109ca"
                }
            },
            {
                "in": "body",
                "name": "body",
                "description": "Action to perform",
                "required": true,
                "schema": {
                    "type": "object",
                    "properties": {
                        "action": {
                            "type": "string",
                            "example": "activate",
                            "description": "The action to perform: 'activate' or 'deactivate'"
                        }
                    },
                    "required": ["action"]
                }
            }
        ],
        "responses": {
            "200": {
                "description": "User status toggled successfully",
                "schema": {
                    "type": "object",
                    "properties": {
                        "msg": { 
                            "type": "string", 
                            "example": "User activated successfully" 
                        },
                        "user": {
                            "type": "object",
                            "properties": {
                                "id": { "type": "string" },
                                "name": { "type": "string" },
                                "email": { "type": "string" },
                                "isActive": { "type": "boolean" }
                            }
                        }
                    }
                }
            },
            "400": {
                "description": "Invalid action",
                "schema": {
                    "type": "object",
                    "properties": {
                        "msg": {
                            "type": "string",
                            "example": "Invalid action"
                        }
                    }
                }
            },
            "404": {
                "description": "User not found",
                "schema": {
                    "type": "object",
                    "properties": {
                        "msg": {
                            "type": "string",
                            "example": "User not found"
                        }
                    }
                }
            },
            "500": {
                "description": "Server error",
                "schema": {
                    "type": "object",
                    "properties": {
                        "msg": {
                            "type": "string",
                            "example": "Server error"
                        }
                    }
                }
            }
        },
        "security": [
            {
                "Bearer": []
            }
        ]
    }
};



module.exports = {
    register,
    login,
    updateProfile,
    getUserById,
    getAllUsers,
    deleteUser,
    toggleUserStatus
};
