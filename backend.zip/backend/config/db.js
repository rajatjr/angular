const mongoose = require('mongoose');
require('dotenv').config();

const mongoosedb = process.env.MONGODB_URI || 'mongodb://localhost:27017/angular_learning';

const connectDB = async () => {
  try {
    await mongoose.connect(mongoosedb, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log('Database Connected Successfully');
  } catch (err) {
    console.error('Database Connection Error:', err);
    process.exit(1); // Exit process with failure
  }
};

// Export the connectDB function
module.exports = connectDB;
