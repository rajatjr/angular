// src/app/signup/signup.component.ts
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { AuthServicesService } from '../../services/auth-services.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {
  signupForm!: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    private http: HttpClient,
    private router: Router,
    private authservice:AuthServicesService
  ) {}

  ngOnInit(): void {
    this.signupForm = this.formBuilder.group({
      name: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(4)]],
      address: ['', [Validators.required]],
      phoneNumber: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]] // Ensure it's a 10-digit number
    });
  }

  onSubmit(): void {
    if (this.signupForm.valid) {
      this.authservice.post('auth/register', this.signupForm.value)
        .subscribe(
          (response: any) => {
            console.log('Signup successful', response);
            // Handle successful signup, e.g., navigate to login or dashboard
            this.router.navigate(['/login']);
          },
          (error) => {
            console.error('Signup failed', error);
            // Handle signup error, e.g., display error message
          }
        );
    }
  }
}
