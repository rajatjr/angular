// // import { Component } from '@angular/core';

// // @Component({
// //   selector: 'app-dashboard',
// //   templateUrl: './dashboard.component.html',
// //   styleUrl: './dashboard.component.scss'
// // })
// // export class DashboardComponent {

// // }

// import { Component, OnInit } from '@angular/core';
// import { AuthServicesService } from '../../services/auth-services.service';

// @Component({
//   selector: 'app-dashboard',
//   templateUrl: './dashboard.component.html',
//   styleUrls: ['./dashboard.component.scss']
// })
// export class DashboardComponent implements OnInit {

//   constructor(public authservice: AuthServicesService) { }

//   ngOnInit(): void {
//     this.getAllUser();
//   }

//   getAllUser() {
//     this.authservice.get('auth/getAllUsers').subscribe(
//       data => {
//         console.log('User data:', data);
//       },
//       error => {
//         console.error('Error fetching users:', error);
//       }
//     );
//   }
// }

// src/app/dashboard/dashboard.component.ts
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthServicesService } from '../../services/auth-services.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  users: any[] = []; // Add a property to hold the user data

  constructor(
    public authservice: AuthServicesService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.getAllUser();
  }

  getAllUser() {
    this.authservice.get('auth/getAllUsers').subscribe(
      data => {
        this.users = data; // Assign the response to the users property
        console.log('User data:', this.users);
      },
      error => {
        console.error('Error fetching users:', error);
      }
    );
  }

  logout() {
    // Remove the token from local storage
    localStorage.removeItem('token');
    // Navigate to the login page
    this.router.navigate(['/login']);
  }
}
