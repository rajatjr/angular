// src/app/login/login.component.ts
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { AuthServicesService } from '../../services/auth-services.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginForm!: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    private http: HttpClient,
    private router: Router,
    private authservice:AuthServicesService
  ) {}

  ngOnInit(): void {
    this.loginForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(4)]]
    });
  }

  onSubmit(): void {
    if (this.loginForm.valid) {
      this.authservice.post('auth/login', this.loginForm.value)
        .subscribe(
          (response: any) => {
            console.log('Login successful', response);
            // Save the token to local storage
            localStorage.setItem('token', response.token);
            // Navigate to dashboard or any other desired page
            this.router.navigate(['/dashboard']);
          },
          (error) => {
            console.error('Login failed', error);
            // Handle login error, e.g., display error message
          }
        );
    }
  }

}
