// import { HttpClient } from '@angular/common/http';
// import { Injectable } from '@angular/core';
// import { Observable } from 'rxjs';

// @Injectable({
//   providedIn: 'root'
// })
// export class AuthServicesService {

//   baseUrl:any="http://localhost:5000/api"

//   constructor(

//     private http: HttpClient
//   ) { }

//   private createUrl(endpoint: string): string {
//     return `${this.baseUrl}/${endpoint}`;
//   }

//   // GET request
//   get(endpoint: string, options?: any): Observable<any> {
//     const url = this.createUrl(endpoint);
//     return this.http.get(url, options);
//   }

//   // POST request
//   post(endpoint: string, data: any, options?: any): Observable<any> {
//     const url = this.createUrl(endpoint);
//     return this.http.post(url, data, options);
//   }

//   // PUT request
//   put(endpoint: string, data: any, options?: any): Observable<any> {
//     const url = this.createUrl(endpoint);
//     return this.http.put(url, data, options);
//   }

//   // PATCH request
//   patch(endpoint: string, data: any, options?: any): Observable<any> {
//     const url = this.createUrl(endpoint);
//     return this.http.patch(url, data, options);
//   }

//   // DELETE request
//   delete(endpoint: string, options?: any): Observable<any> {
//     const url = this.createUrl(endpoint);
//     return this.http.delete(url, options);
//   }
// }


import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthServicesService {

  baseUrl: any = 'http://localhost:5000/api';

  constructor(private http: HttpClient) { }

  private createUrl(endpoint: string): string {
    return `${this.baseUrl}/${endpoint}`;
  }

  private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem('token'); // Replace with actual token retrieval logic
    return new HttpHeaders({
      'Authorization': `Bearer ${token}`
    });
  }

  // GET request
  get(endpoint: string, options?: any): Observable<any> {
    const url = this.createUrl(endpoint);
    const headers = this.getAuthHeaders();
    return this.http.get(url, { headers, ...options });
  }

  // POST request
  post(endpoint: string, data: any, options?: any): Observable<any> {
    const url = this.createUrl(endpoint);
    const headers = this.getAuthHeaders();
    return this.http.post(url, data, { headers, ...options });
  }

  // PUT request
  put(endpoint: string, data: any, options?: any): Observable<any> {
    const url = this.createUrl(endpoint);
    const headers = this.getAuthHeaders();
    return this.http.put(url, data, { headers, ...options });
  }

  // PATCH request
  patch(endpoint: string, data: any, options?: any): Observable<any> {
    const url = this.createUrl(endpoint);
    const headers = this.getAuthHeaders();
    return this.http.patch(url, data, { headers, ...options });
  }

  // DELETE request
  delete(endpoint: string, options?: any): Observable<any> {
    const url = this.createUrl(endpoint);
    const headers = this.getAuthHeaders();
    return this.http.delete(url, { headers, ...options });
  }
}
